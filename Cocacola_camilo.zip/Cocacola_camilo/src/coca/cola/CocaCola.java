package coca.cola;

import java.util.Scanner;

public class CocaCola {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        String nombre = "";
        int antiguedad = 0;
        int clave = 0;

        System.out.println("****************************************************************");
        System.out.println("Bienvenido al sistema de vacaciones de The Coca-Cola Company");
        System.out.println("****************************************************************\n");

        System.out.print("Digite el nombre del empleado: ");
        nombre = entrada.nextLine();

        System.out.print("Digite la antiguedad del empleado: ");
        antiguedad = entrada.nextInt();

        System.out.print("Digite la clave del departamento (1, 2 o 3): ");
        clave = entrada.nextInt();

        if (clave == 1) {
            if (antiguedad == 1) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 6 dias vacacionales.");
            } else if (antiguedad >= 2 && antiguedad <= 6) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 14 dias vacacionales.");
            } else if (antiguedad >= 7) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 20 dias vacacionales.");
            } else {
                System.out.println("El trabajador aun no tiene derecho a vacaciones.");
            }
        } else if (clave == 2) {
            if (antiguedad == 1) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 7 dias vacacionales.");
            } else if (antiguedad >= 2 && antiguedad <= 6) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 15 dias vacacionales.");
            } else if (antiguedad >= 7) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 22 dias vacacionales.");
            } else {
                System.out.println("El trabajador aun no tiene derecho a vacaciones.");
            }
        } else if (clave == 3) {
            if (antiguedad == 1) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 10 dias vacacionales.");
            } else if (antiguedad >= 2 && antiguedad <= 6) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 20 dias vacacionales.");
            } else if (antiguedad >= 7) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 30 dias vacacionales.");
            } else {
                System.out.println("El trabajador aun no tiene derecho a vacaciones.");
            }
        } else {
            System.out.println("Error: La clave del departamento no existe.");
        }
    }
}
