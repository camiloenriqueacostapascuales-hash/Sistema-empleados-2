package alumno;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author camil
 */
public class clase_alumnos {
    private String nombre;
    private String carrera;
    private String grupo;
    private String semestre;
    private Object promedio;

    public clase_alumnos() {
    }

    public clase_alumnos(String nombre, String carrera, String grupo, String semestre, Object promedio) {
        this.nombre = nombre;
        this.carrera = carrera;
        this.grupo = grupo;
        this.semestre = semestre;
        this.promedio = promedio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public String getSemestre() {
        return semestre;
    }

    public void setSemestre(String semestre) {
        this.semestre = semestre;
    }

    public Object getPromedio() {
        return promedio;
    }

    public void setPromedio(Object promedio) {
        this.promedio = promedio;
    }

    @Override
    public String toString() {
        return "Alumno{" +
                "nombre='" + nombre + '\'' +
                ", carrera='" + carrera + '\'' +
                ", grupo='" + grupo + '\'' +
                ", semestre='" + semestre + '\'' +
                ", promedio=" + promedio +
                '}';
    }

    public boolean estaAprobado() {
        try {
            double p = Double.parseDouble(promedio.toString());
            return p >= 3.0;
        } catch (Exception e) {
            return false;
        }
    }
}