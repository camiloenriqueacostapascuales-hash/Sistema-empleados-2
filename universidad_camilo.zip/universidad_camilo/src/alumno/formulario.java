package alumno;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 * Formulario de registro de alumnos dentro del paquete alumno.
 * 
 * @author camil
 */
public class formulario extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(formulario.class.getName());

    DefaultTableModel modelo = new DefaultTableModel();
    ArrayList<clase_alumnos> listaAlumnos = new ArrayList<>();

    // Variables para la animación luminosa y hover de la tabla
    private int filaAnimada = -1;
    private float animacionProgreso = 0f;
    private javax.swing.Timer timerAnimacion;
    private int filaHover = -1;

    /**
     * Creates new form formulario
     */
    public formulario() {
        initComponents();
        this.setTitle("Sistema de Registro de Estudiantes");
        this.setSize(980, 630);
        this.setLocationRelativeTo(null);
        modelo.addColumn("Nombre");
        modelo.addColumn("Carrera");
        modelo.addColumn("Grupo");
        modelo.addColumn("Semestre");
        modelo.addColumn("Promedio");
        RefrescarTabla();

        // Aplicar paleta clean en tonos oscuros y azulados suaves con animaciones
        aplicarEstiloModerno();

        // Al hacer clic en una fila de la tabla, cargar los datos en el formulario
        TbRegistro.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                seleccionarFila();
            }
        });
    }

    @SuppressWarnings("unchecked")
    public void RefrescarTabla() {
        TbRegistro.setModel(modelo);
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        CBCCARRERAALUMNOS = new javax.swing.JComboBox<>();
        CBCGRUPOALUMNOS = new javax.swing.JComboBox<>();
        Alumnos = new javax.swing.JTextField();
        jComboBox3 = new javax.swing.JComboBox<>();
        jSpinner1 = new javax.swing.JSpinner();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TbRegistro = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel1.setForeground(new java.awt.Color(51, 153, 255));

        jLabel1.setText("REGISTRO DE ALUMNOS");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(281, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(265, 265, 265))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel1)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        jLabel2.setText("Nombres");

        jLabel3.setText("Carrera");

        jLabel4.setText("Grupo");

        jLabel5.setText("Semestre");

        jLabel6.setText("Promedio");

        CBCCARRERAALUMNOS.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ING SOFTWARE", "DERECHO", "POLITOLOGIA", "ING CIVIL", "LENGUAS EXTRANJERAS", " " }));
        CBCCARRERAALUMNOS.addActionListener(this::CBCCARRERAALUMNOSActionPerformed);

        CBCGRUPOALUMNOS.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "GRUPO 1", "GRUPO 2", "GRUPO 3", "GRUPO 4", " " }));

        Alumnos.setText("");

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));

        jButton1.setBackground(new java.awt.Color(51, 51, 255));
        jButton1.setText("GUARDAR");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        jButton2.setBackground(new java.awt.Color(255, 0, 51));
        jButton2.setText("BORRAR");
        jButton2.addActionListener(this::jButton2ActionPerformed);

        TbRegistro.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(TbRegistro);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(91, 91, 91)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(71, 71, 71)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(CBCCARRERAALUMNOS, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(CBCGRUPOALUMNOS, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Alumnos, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox3, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jSpinner1))
                        .addGap(74, 74, 74)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(91, 91, 91)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(Alumnos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(CBCCARRERAALUMNOS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(CBCGRUPOALUMNOS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            String nombre = Alumnos.getText().trim();
            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor, ingrese el nombre del alumno.", "Campo requerido",
                        JOptionPane.WARNING_MESSAGE);
                Alumnos.requestFocus();
                return;
            }

            String carrera = CBCCARRERAALUMNOS.getSelectedItem() != null
                    ? CBCCARRERAALUMNOS.getSelectedItem().toString().trim()
                    : "";
            String grupo = CBCGRUPOALUMNOS.getSelectedItem() != null
                    ? CBCGRUPOALUMNOS.getSelectedItem().toString().trim()
                    : "";
            String semestre = jComboBox3.getSelectedItem() != null
                    ? jComboBox3.getSelectedItem().toString().trim()
                    : "";
            Object promedio = jSpinner1.getValue();

            // Instanciar el objeto alumno y agregarlo a la lista de estudiantes
            clase_alumnos nuevoAlumno = new clase_alumnos(nombre, carrera, grupo, semestre, promedio);
            listaAlumnos.add(nuevoAlumno);

            // Agregar la fila a la tabla visual
            Object[] fila = { nombre, carrera, grupo, semestre, promedio };
            modelo.addRow(fila);

            // Disparar animación luminosa sobre la fila agregada
            int nuevaFila = modelo.getRowCount() - 1;
            iniciarAnimacionFila(nuevaFila);

            // Limpiar los campos para un nuevo ingreso
            limpiarCampos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al guardar el registro: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        int filaSeleccionada = TbRegistro.getSelectedRow();
        if (filaSeleccionada >= 0) {
            int confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro de eliminar el registro seleccionado?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) {
                if (filaSeleccionada < listaAlumnos.size()) {
                    listaAlumnos.remove(filaSeleccionada);
                }
                modelo.removeRow(filaSeleccionada);
                limpiarCampos();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione una fila de la tabla para borrar.", "Aviso",
                    JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void CBCCARRERAALUMNOSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CBCCARRERAALUMNOSActionPerformed
        // Evento al cambiar de carrera seleccionada
    }//GEN-LAST:event_CBCCARRERAALUMNOSActionPerformed

    /**
     * Inicia una animación luminosa suave (glow & fade) en la fila recién insertada.
     */
    private void iniciarAnimacionFila(int fila) {
        this.filaAnimada = fila;
        this.animacionProgreso = 1.0f;
        if (timerAnimacion != null && timerAnimacion.isRunning()) {
            timerAnimacion.stop();
        }
        timerAnimacion = new javax.swing.Timer(16, e -> {
            animacionProgreso -= 0.035f;
            if (animacionProgreso <= 0f) {
                animacionProgreso = 0f;
                filaAnimada = -1;
                ((javax.swing.Timer) e.getSource()).stop();
            }
            TbRegistro.repaint();
        });
        timerAnimacion.start();
        TbRegistro.scrollRectToVisible(TbRegistro.getCellRect(fila, 0, true));
    }

    /**
     * Aplica la estética moderna en tonos negros y azules suaves a todos los componentes.
     */
    private void aplicarEstiloModerno() {
        // Fondo general de la ventana (Negro azulado profundo #0F172A)
        getContentPane().setBackground(new java.awt.Color(15, 23, 42));

        // Panel del encabezado con tarjeta oscura y borde azul suave
        jPanel1.setBackground(new java.awt.Color(30, 41, 59)); // Slate oscuro #1E293B
        jPanel1.setBorder(javax.swing.BorderFactory.createCompoundBorder(
            javax.swing.BorderFactory.createLineBorder(new java.awt.Color(56, 189, 248, 140), 1, true),
            javax.swing.BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));

        // Título estilizado en Segoe UI con color azul cielo suave
        jLabel1.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 22));
        jLabel1.setForeground(new java.awt.Color(56, 189, 248)); // #38BDF8
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        // Tipografía y colores de etiquetas del formulario
        java.awt.Font fontLabels = new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13);
        java.awt.Color colorLabels = new java.awt.Color(203, 213, 225); // #CBD5E1

        javax.swing.JLabel[] labels = {jLabel2, jLabel3, jLabel4, jLabel5, jLabel6};
        for (javax.swing.JLabel lbl : labels) {
            lbl.setFont(fontLabels);
            lbl.setForeground(colorLabels);
        }

        // Estilo de inputs y controles (Fondo oscuro, texto blanco, borde azul suave)
        java.awt.Font fontInputs = new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13);
        java.awt.Color bgInput = new java.awt.Color(30, 41, 59);
        java.awt.Color fgInput = new java.awt.Color(248, 250, 252);
        javax.swing.border.Border borderInput = javax.swing.BorderFactory.createCompoundBorder(
            javax.swing.BorderFactory.createLineBorder(new java.awt.Color(56, 189, 248, 100), 1, true),
            javax.swing.BorderFactory.createEmptyBorder(5, 10, 5, 10)
        );

        Alumnos.setFont(fontInputs);
        Alumnos.setBackground(bgInput);
        Alumnos.setForeground(fgInput);
        Alumnos.setCaretColor(new java.awt.Color(56, 189, 248));
        Alumnos.setBorder(borderInput);

        javax.swing.JComboBox<?>[] combos = {CBCCARRERAALUMNOS, CBCGRUPOALUMNOS, jComboBox3};
        for (javax.swing.JComboBox<?> cb : combos) {
            cb.setFont(fontInputs);
            cb.setBackground(bgInput);
            cb.setForeground(fgInput);
            cb.setBorder(borderInput);
        }

        // Apartado del promedio: números visibles en negro con tipografía nítida
        jSpinner1.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14));
        jSpinner1.setBackground(java.awt.Color.WHITE);
        jSpinner1.setBorder(javax.swing.BorderFactory.createCompoundBorder(
            javax.swing.BorderFactory.createLineBorder(new java.awt.Color(56, 189, 248, 160), 1, true),
            javax.swing.BorderFactory.createEmptyBorder(3, 6, 3, 6)
        ));
        javax.swing.JComponent editor = jSpinner1.getEditor();
        if (editor instanceof javax.swing.JSpinner.DefaultEditor) {
            javax.swing.JTextField tf = ((javax.swing.JSpinner.DefaultEditor) editor).getTextField();
            tf.setBackground(java.awt.Color.WHITE);
            tf.setForeground(java.awt.Color.BLACK);
            tf.setCaretColor(java.awt.Color.BLACK);
            tf.setSelectedTextColor(java.awt.Color.WHITE);
            tf.setSelectionColor(new java.awt.Color(2, 132, 199));
            tf.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14));
        }

        // Botón GUARDAR (Azul suave vibrante con hover animado)
        jButton1.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));
        jButton1.setBackground(new java.awt.Color(37, 99, 235)); // #2563EB
        jButton1.setForeground(java.awt.Color.WHITE);
        jButton1.setFocusPainted(false);
        jButton1.setBorder(javax.swing.BorderFactory.createEmptyBorder(8, 16, 8, 16));
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                jButton1.setBackground(new java.awt.Color(59, 130, 246)); // #3B82F6
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                jButton1.setBackground(new java.awt.Color(37, 99, 235));
            }
        });

        // Botón BORRAR (Carmesí suave con hover animado)
        jButton2.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));
        jButton2.setBackground(new java.awt.Color(225, 29, 72)); // #E11D48
        jButton2.setForeground(java.awt.Color.WHITE);
        jButton2.setFocusPainted(false);
        jButton2.setBorder(javax.swing.BorderFactory.createEmptyBorder(8, 16, 8, 16));
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                jButton2.setBackground(new java.awt.Color(244, 63, 94)); // #F43F5E
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                jButton2.setBackground(new java.awt.Color(225, 29, 72));
            }
        });

        // Configuración y animación de la tabla
        configurarTablaEstiloYAnimacion();
    }

    /**
     * Configura la tabla con diseño flat, cabecera oscura y azulada, y animación de filas.
     */
    private void configurarTablaEstiloYAnimacion() {
        TbRegistro.setRowHeight(34);
        TbRegistro.setShowGrid(true);
        TbRegistro.setGridColor(new java.awt.Color(30, 41, 59));
        TbRegistro.setBackground(new java.awt.Color(15, 23, 42));
        TbRegistro.setForeground(new java.awt.Color(241, 245, 249));
        TbRegistro.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13));
        TbRegistro.setSelectionBackground(new java.awt.Color(2, 132, 199)); // #0284C7
        TbRegistro.setSelectionForeground(java.awt.Color.WHITE);
        TbRegistro.setFillsViewportHeight(true);

        // Cabecera estilizada en tonos negros y azulados
        javax.swing.table.JTableHeader header = TbRegistro.getTableHeader();
        header.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));
        header.setBackground(new java.awt.Color(30, 41, 59));
        header.setForeground(new java.awt.Color(56, 189, 248));
        header.setPreferredSize(new java.awt.Dimension(header.getWidth(), 38));
        header.setReorderingAllowed(false);
        header.setDefaultRenderer(new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(
                    javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                java.awt.Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setBackground(new java.awt.Color(30, 41, 59));
                setForeground(new java.awt.Color(56, 189, 248));
                setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));
                setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
                setBorder(javax.swing.BorderFactory.createCompoundBorder(
                    javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 1, new java.awt.Color(56, 189, 248, 120)),
                    javax.swing.BorderFactory.createEmptyBorder(6, 12, 6, 12)
                ));
                return c;
            }
        });

        // Renderer de celdas con animación suave (glow & fade), alternancia de color y hover
        TbRegistro.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(
                    javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                java.awt.Component comp = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 12, 0, 12));

                if (isSelected) {
                    comp.setBackground(new java.awt.Color(2, 132, 199));
                    comp.setForeground(java.awt.Color.WHITE);
                } else if (row == filaAnimada && animacionProgreso > 0f) {
                    // Animación luminosa: azul suave resplandeciente que se disuelve progresivamente
                    int r = (int) (15 + (56 - 15) * animacionProgreso);
                    int g = (int) (23 + (189 - 23) * animacionProgreso);
                    int b = (int) (42 + (248 - 42) * animacionProgreso);
                    comp.setBackground(new java.awt.Color(r, g, b));
                    comp.setForeground(animacionProgreso > 0.4f ? new java.awt.Color(15, 23, 42) : java.awt.Color.WHITE);
                } else if (row == filaHover) {
                    // Efecto hover interactivo sobre la fila
                    comp.setBackground(new java.awt.Color(30, 58, 95));
                    comp.setForeground(new java.awt.Color(248, 250, 252));
                } else {
                    // Filas alternadas en tonos oscuros y azul marino
                    if (row % 2 == 0) {
                        comp.setBackground(new java.awt.Color(15, 23, 42)); // #0F172A
                    } else {
                        comp.setBackground(new java.awt.Color(22, 32, 50)); // #162032
                    }
                    comp.setForeground(new java.awt.Color(226, 232, 240));
                }
                return comp;
            }
        });

        // Detección de movimiento del ratón para hover animado en filas
        TbRegistro.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            @Override
            public void mouseMoved(java.awt.event.MouseEvent e) {
                int row = TbRegistro.rowAtPoint(e.getPoint());
                if (row != filaHover) {
                    filaHover = row;
                    TbRegistro.repaint();
                }
            }
        });

        TbRegistro.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                filaHover = -1;
                TbRegistro.repaint();
            }
        });

        jScrollPane1.getViewport().setBackground(new java.awt.Color(15, 23, 42));
        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(56, 189, 248, 80), 1, true));
    }

    /**
     * Carga los datos de la fila seleccionada de la tabla en los campos del formulario.
     */
    public void seleccionarFila() {
        int fila = TbRegistro.getSelectedRow();
        if (fila >= 0) {
            Alumnos.setText(modelo.getValueAt(fila, 0) != null ? modelo.getValueAt(fila, 0).toString() : "");
            if (modelo.getValueAt(fila, 1) != null) {
                CBCCARRERAALUMNOS.setSelectedItem(modelo.getValueAt(fila, 1).toString());
            }
            if (modelo.getValueAt(fila, 2) != null) {
                CBCGRUPOALUMNOS.setSelectedItem(modelo.getValueAt(fila, 2).toString());
            }
            if (modelo.getValueAt(fila, 3) != null) {
                jComboBox3.setSelectedItem(modelo.getValueAt(fila, 3).toString());
            }
            if (modelo.getValueAt(fila, 4) != null) {
                jSpinner1.setValue(modelo.getValueAt(fila, 4));
            }
        }
    }

    /**
     * Limpia todos los campos del formulario y restablece los valores por defecto.
     */
    public void limpiarCampos() {
        Alumnos.setText("");
        if (CBCCARRERAALUMNOS.getItemCount() > 0) {
            CBCCARRERAALUMNOS.setSelectedIndex(0);
        }
        if (CBCGRUPOALUMNOS.getItemCount() > 0) {
            CBCGRUPOALUMNOS.setSelectedIndex(0);
        }
        if (jComboBox3.getItemCount() > 0) {
            jComboBox3.setSelectedIndex(0);
        }
        jSpinner1.setValue(0);
        Alumnos.requestFocus();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /*
         * If Nimbus (introduced in Java SE 6) is not available, stay with the default
         * look and feel.
         * For details see
         * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new formulario().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Alumnos;
    private javax.swing.JComboBox<String> CBCCARRERAALUMNOS;
    private javax.swing.JComboBox<String> CBCGRUPOALUMNOS;
    private javax.swing.JTable TbRegistro;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinner1;
    // End of variables declaration//GEN-END:variables
}
