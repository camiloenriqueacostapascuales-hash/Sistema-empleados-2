package alumno;

/**
 * Clase alumnos que extiende de clase_alumnos para compatibilidad total
 * con cualquier referencia a la clase 'alumnos'.
 * 
 * @author camil
 */
public class alumnos extends clase_alumnos {

    public alumnos() {
        super();
    }

    public alumnos(String nombre, String carrera, String grupo, String semestre, Object promedio) {
        super(nombre, carrera, grupo, semestre, promedio);
    }
}
