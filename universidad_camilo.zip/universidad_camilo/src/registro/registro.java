package registro;

/**
 * Clase de compatibilidad que hereda de formulario_registro.
 * Permite ejecutar o referenciar tanto 'registro' como 'formulario_registro'.
 * 
 * @author camil
 */
public class registro extends formulario_registro {

    public registro() {
        super();
    }

    public static void main(String args[]) {
        formulario_registro.main(args);
    }
}
