package com.mycompany.empleados;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Locale;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * Ventana principal del sistema de Registro de Empleados.
 * @author camil
 */
public class VentanaEmpleados extends JFrame {

    // Componentes del formulario
    private JTextField txtNombre;
    private JTextField txtDocumento;
    private JComboBox<String> cmbCargo;
    private JComboBox<String> cmbArea;
    private JSpinner spnSalario;
    private JTextField txtFechaIngreso;

    // Botones
    private JButton btnGuardar;
    private JButton btnLimpiar;
    private JButton btnEliminar;

    // Tabla
    private JTable tablaEmpleados;
    private DefaultTableModel modeloTabla;

    // Labels de estadísticas
    private JLabel lblTotalEmpleados;
    private JLabel lblPromedioSalarial;
    private JLabel lblMayorSalario;

    // Lista de empleados
    private ArrayList<Empleado> listaEmpleados = new ArrayList<>();

    // Formateador de moneda con separador de miles (,) y decimales (.)
    private DecimalFormat df = new DecimalFormat("$ #,##0.00", new DecimalFormatSymbols(Locale.US));

    public VentanaEmpleados() {
        setTitle("REGISTRO DE EMPLEADOS");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);

        // ==================== TITULO ====================
        JLabel lblTitulo = new JLabel("REGISTRO DE EMPLEADOS");
        lblTitulo.setBounds(300, 10, 400, 30);
        lblTitulo.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 20));
        add(lblTitulo);

        // ==================== FORMULARIO ====================
        JLabel lblNombre = new JLabel("Nombre Completo:");
        lblNombre.setBounds(30, 60, 130, 25);
        add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(170, 60, 200, 25);
        add(txtNombre);

        JLabel lblDocumento = new JLabel("Documento:");
        lblDocumento.setBounds(30, 100, 130, 25);
        add(lblDocumento);

        txtDocumento = new JTextField();
        txtDocumento.setBounds(170, 100, 200, 25);
        add(txtDocumento);

        JLabel lblCargo = new JLabel("Cargo:");
        lblCargo.setBounds(30, 140, 130, 25);
        add(lblCargo);

        String[] cargos = {"-- Seleccione --", "Auxiliar", "Analista", "Supervisor", "Coordinador"};
        cmbCargo = new JComboBox<>(cargos);
        cmbCargo.setBounds(170, 140, 200, 25);
        add(cmbCargo);

        JLabel lblArea = new JLabel("Área:");
        lblArea.setBounds(30, 180, 130, 25);
        add(lblArea);

        String[] areas = {"-- Seleccione --", "Recursos Humanos", "Sistemas", "Contabilidad", "Producción"};
        cmbArea = new JComboBox<>(areas);
        cmbArea.setBounds(170, 180, 200, 25);
        add(cmbArea);

        JLabel lblSalario = new JLabel("Salario:");
        lblSalario.setBounds(30, 220, 130, 25);
        add(lblSalario);

        SpinnerNumberModel modeloSalario = new SpinnerNumberModel(0.0, 0.0, 100000000.0, 50000.0);
        spnSalario = new JSpinner(modeloSalario);
        spnSalario.setBounds(170, 220, 200, 25);
        add(spnSalario);

        JLabel lblFecha = new JLabel("Fecha de Ingreso:");
        lblFecha.setBounds(30, 260, 130, 25);
        add(lblFecha);

        txtFechaIngreso = new JTextField();
        txtFechaIngreso.setBounds(170, 260, 200, 25);
        txtFechaIngreso.setToolTipText("Formato: DD/MM/AAAA");
        add(txtFechaIngreso);

        // ==================== BOTONES ====================
        btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(30, 310, 120, 35);
        btnGuardar.setBackground(new java.awt.Color(30, 120, 220)); // Azul
        btnGuardar.setForeground(java.awt.Color.WHITE);
        btnGuardar.setFocusPainted(false);
        add(btnGuardar);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(160, 310, 120, 35);
        add(btnLimpiar);

        btnEliminar = new JButton("Eliminar Registro");
        btnEliminar.setBounds(290, 310, 150, 35);
        btnEliminar.setBackground(new java.awt.Color(220, 50, 50)); // Rojo
        btnEliminar.setForeground(java.awt.Color.WHITE);
        btnEliminar.setFocusPainted(false);
        add(btnEliminar);

        // ==================== TABLA ====================
        String[] columnas = {"NOMBRE", "DOCUMENTO", "CARGO", "ÁREA", "SALARIO", "FECHA INGRESO"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tablaEmpleados = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaEmpleados);
        scrollPane.setBounds(450, 60, 420, 285);
        add(scrollPane);

        // ==================== ESTADISTICAS (Nivel Avanzado) ====================
        JLabel lblEstTitulo = new JLabel("--- Estadísticas ---");
        lblEstTitulo.setBounds(30, 370, 200, 25);
        lblEstTitulo.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 14));
        add(lblEstTitulo);

        JLabel lblTextoTotal = new JLabel("Total empleados:");
        lblTextoTotal.setBounds(30, 400, 130, 25);
        add(lblTextoTotal);

        lblTotalEmpleados = new JLabel("0");
        lblTotalEmpleados.setBounds(170, 400, 200, 25);
        add(lblTotalEmpleados);

        JLabel lblTextoPromedio = new JLabel("Promedio salarial:");
        lblTextoPromedio.setBounds(30, 430, 130, 25);
        add(lblTextoPromedio);

        lblPromedioSalarial = new JLabel("$ 0.00");
        lblPromedioSalarial.setBounds(170, 430, 200, 25);
        add(lblPromedioSalarial);

        JLabel lblTextoMayor = new JLabel("Mayor salario:");
        lblTextoMayor.setBounds(30, 460, 130, 25);
        add(lblTextoMayor);

        lblMayorSalario = new JLabel("Ninguno");
        lblMayorSalario.setBounds(170, 460, 300, 25);
        add(lblMayorSalario);

        // ==================== EVENTOS DE LOS BOTONES ====================
        btnGuardar.addActionListener(e -> guardar());
        btnLimpiar.addActionListener(e -> limpiar());
        btnEliminar.addActionListener(e -> eliminar());
    }

    /**
     * Guarda un nuevo empleado validando los campos.
     */
    private void guardar() {
        String nombre = txtNombre.getText().trim();
        String documento = txtDocumento.getText().trim();
        int indiceCargo = cmbCargo.getSelectedIndex();
        int indiceArea = cmbArea.getSelectedIndex();
        double salario = ((Number) spnSalario.getValue()).doubleValue();
        String fecha = txtFechaIngreso.getText().trim();

        // Validaciones (Nivel Intermedio)
        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar el nombre del empleado.");
            return;
        }
        if (documento.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar el documento.");
            return;
        }
        if (indiceCargo == 0) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar un cargo.");
            return;
        }
        if (indiceArea == 0) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar un área.");
            return;
        }
        if (salario <= 0) {
            JOptionPane.showMessageDialog(this, "El salario debe ser mayor a 0.");
            return;
        }
        if (fecha.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar la fecha de ingreso.");
            return;
        }

        String cargo = (String) cmbCargo.getSelectedItem();
        String area = (String) cmbArea.getSelectedItem();

        // Crear empleado y agregarlo a la lista
        Empleado emp = new Empleado(nombre, documento, cargo, area, salario, fecha);
        listaEmpleados.add(emp);

        // Agregar a la tabla con formato de moneda y decimales
        modeloTabla.addRow(new Object[]{nombre, documento, cargo, area, df.format(salario), fecha});

        // Actualizar estadísticas
        actualizarEstadisticas();

        JOptionPane.showMessageDialog(this, "Empleado registrado exitosamente.");
        limpiar();
    }

    /**
     * Limpia todos los campos del formulario.
     */
    private void limpiar() {
        txtNombre.setText("");
        txtDocumento.setText("");
        cmbCargo.setSelectedIndex(0);
        cmbArea.setSelectedIndex(0);
        spnSalario.setValue(0.0);
        txtFechaIngreso.setText("");
        txtNombre.requestFocus();
    }

    /**
     * Elimina el registro seleccionado de la tabla.
     */
    private void eliminar() {
        int fila = tablaEmpleados.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un empleado de la tabla para eliminar.");
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(this,
                "¿Está seguro de eliminar este registro?",
                "Confirmar", JOptionPane.YES_NO_OPTION);

        if (confirmacion == JOptionPane.YES_OPTION) {
            listaEmpleados.remove(fila);
            modeloTabla.removeRow(fila);
            actualizarEstadisticas();
            JOptionPane.showMessageDialog(this, "Registro eliminado.");
        }
    }

    /**
     * Calcula y muestra las estadísticas (Nivel Avanzado).
     */
    private void actualizarEstadisticas() {
        int total = listaEmpleados.size();
        lblTotalEmpleados.setText(String.valueOf(total));

        if (total == 0) {
            lblPromedioSalarial.setText("$ 0.00");
            lblMayorSalario.setText("Ninguno");
            return;
        }

        double suma = 0;
        Empleado mayor = listaEmpleados.get(0);

        for (Empleado emp : listaEmpleados) {
            suma += emp.getSalario();
            if (emp.getSalario() > mayor.getSalario()) {
                mayor = emp;
            }
        }

        double promedio = suma / total;
        lblPromedioSalarial.setText(df.format(promedio));
        lblMayorSalario.setText(mayor.getNombre() + " (" + df.format(mayor.getSalario()) + ")");
    }
}
