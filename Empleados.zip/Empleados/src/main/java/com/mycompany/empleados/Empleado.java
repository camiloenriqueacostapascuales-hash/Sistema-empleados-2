package com.mycompany.empleados;

/**
 * Clase que representa un Empleado.
 * @author camil
 */
public class Empleado {

    private String nombre;
    private String documento;
    private String cargo;
    private String area;
    private double salario;
    private String fechaIngreso;

    public Empleado(String nombre, String documento, String cargo, String area, double salario, String fechaIngreso) {
        this.nombre = nombre;
        this.documento = documento;
        this.cargo = cargo;
        this.area = area;
        this.salario = salario;
        this.fechaIngreso = fechaIngreso;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDocumento() {
        return documento;
    }

    public String getCargo() {
        return cargo;
    }

    public String getArea() {
        return area;
    }

    public double getSalario() {
        return salario;
    }

    public String getFechaIngreso() {
        return fechaIngreso;
    }
}
