package com.mycompany.empleados;

/**
 * Clase principal que inicia la aplicación.
 * @author camil
 */
public class Empleados {

    public static void main(String[] args) {
        VentanaEmpleados ventana = new VentanaEmpleados();
        ventana.setVisible(true);
    }
}
