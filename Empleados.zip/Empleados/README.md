# Sistema de Registro de Empleados

Aplicación de escritorio desarrollada en **Java Swing** y gestionada con **Apache Maven** en Apache NetBeans para la gestión y registro de personal de una empresa.

---

## 📋 Requerimientos Implementados

### 1. Formulario de Registro
- **Título:** `REGISTRO DE EMPLEADOS`
- **Campos del Formulario:**
  - **Nombre Completo:** `JTextField` (`txtNombre`)
  - **Documento:** `JTextField` (`txtDocumento`), incluye validación de documento no duplicado.
  - **Cargo:** `JComboBox` con opciones:
    - *Auxiliar*
    - *Analista*
    - *Supervisor*
    - *Coordinador*
  - **Área:** `JComboBox` con opciones:
    - *Recursos Humanos*
    - *Sistemas*
    - *Contabilidad*
    - *Producción*
  - **Salario:** `JSpinner` (`spnSalario`) con formato numérico y saltos de $50.000.
  - **Fecha de Ingreso:** `JFormattedTextField` (`txtFechaIngreso`) con máscara `##/##/####` (`dd/MM/yyyy`) y validación de fecha real.

### 2. Botones y Acciones
- **Guardar:**
  - Captura la información ingresada.
  - Valida que ningún campo quede vacío.
  - Valida que el salario sea estrictamente mayor a 0.
  - Agrega el registro a la `JTable`.
  - Recalcula las estadísticas del Nivel Avanzado.
  - Limpia el formulario automáticamente.
- **Limpiar:**
  - Restablece todos los campos a su valor inicial o vacío y enfoca el campo de Nombre.
- **Eliminar Registro:**
  - Valida que el usuario haya seleccionado una fila en la tabla.
  - Solicita confirmación previa (`JOptionPane.showConfirmDialog`).
  - Remueve el registro de la tabla y de la lista interna, recalculando las estadísticas.

### 3. Tabla de Datos (`JTable`)
- Columnas: `NOMBRE`, `DOCUMENTO`, `CARGO`, `ÁREA`, `SALARIO` y `FECHA DE INGRESO`.
- Encabezado con estilo moderno, filas no editables directamente y celdas alineadas según el tipo de dato (salarios a la derecha, códigos y fechas centradas).

### 4. Niveles de la Actividad
- **Nivel Básico:**
  - [x] Registrar empleados.
  - [x] Mostrar registros en tabla.
  - [x] Limpiar formulario.
- **Nivel Intermedio:**
  - [x] Validar que el salario sea mayor a 0.
  - [x] Mostrar mensaje descriptivo (`JOptionPane`) si falta información o algún campo es inválido.
- **Nivel Avanzado:**
  - [x] Cantidad total de empleados registrados.
  - [x] Promedio salarial calculado dinámicamente y formateado como moneda.
  - [x] Empleado con mayor salario registrado (nombre y monto).

---

## 🏗️ Estructura del Código

```
Empleados/
├── pom.xml                                    # Configuración del proyecto Maven (Java 17)
├── README.md                                  # Documentación del proyecto
└── src/
    └── main/
        └── java/
            └── com/
                └── mycompany/
                    └── empleados/
                        ├── Empleado.java             # Clase modelo (POO)
                        ├── VentanaEmpleados.java     # Interfaz gráfica Swing (JFrame)
                        └── Empleados.java            # Clase principal (Main)
```

---

## 🚀 Cómo Ejecutar el Proyecto

### Desde Apache NetBeans:
1. Abrir **NetBeans**.
2. Ir a **File** > **Open Project...** y seleccionar la carpeta `Empleados`.
3. Hacer clic derecho sobre el proyecto y elegir **Clean and Build** (o `Shift + F11`).
4. Presionar el botón verde **Run Project** (o presionar `F6`).

### Desde la Línea de Comandos:
```bash
mvn compile
mvn exec:java
```

